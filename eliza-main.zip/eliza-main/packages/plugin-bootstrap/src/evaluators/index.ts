export * from "./fact.ts";
export * from "./goal.ts";
