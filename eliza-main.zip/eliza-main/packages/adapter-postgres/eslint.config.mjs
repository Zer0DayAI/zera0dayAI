import eslintGlobalConfig from "../../eslint.global.mjs";

export default [...eslintGlobalConfig];
