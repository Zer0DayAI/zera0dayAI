[@ai16z/eliza v1.0.0](../index.md) / booleanFooter

# Variable: booleanFooter

> `const` **booleanFooter**: `"Respond with a YES or a NO."`

## Defined in

[packages/core/src/parsing.ts:34](https://github.com/ai16z/eliza/blob/main/packages/core/src/parsing.ts#L34)
