[@ai16z/eliza v1.0.0](../index.md) / getEndpoint

# Function: getEndpoint()

> **getEndpoint**(`provider`): `string`

## Parameters

• **provider**: [`ModelProviderName`](../enumerations/ModelProviderName.md)

## Returns

`string`

## Defined in

[packages/core/src/models.ts:246](https://github.com/ai16z/eliza/blob/main/packages/core/src/models.ts#L246)
