[@ai16z/eliza v1.0.0](../index.md) / formatGoalsAsString

# Function: formatGoalsAsString()

> **formatGoalsAsString**(`__namedParameters`): `string`

## Parameters

• **\_\_namedParameters**

• **\_\_namedParameters.goals**: [`Goal`](../interfaces/Goal.md)[]

## Returns

`string`

## Defined in

[packages/core/src/goals.ts:29](https://github.com/ai16z/eliza/blob/main/packages/core/src/goals.ts#L29)
