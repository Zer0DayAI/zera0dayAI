# Enumeration: Clients

## Enumeration Members

### DIRECT

> **DIRECT**: `"direct"`

#### Defined in

[packages/core/src/types.ts:322](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/types.ts#L322)

---

### DISCORD

> **DISCORD**: `"discord"`

#### Defined in

[packages/core/src/types.ts:321](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/types.ts#L321)

---

### TELEGRAM

> **TELEGRAM**: `"telegram"`

#### Defined in

[packages/core/src/types.ts:324](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/types.ts#L324)

---

### TWITTER

> **TWITTER**: `"twitter"`

#### Defined in

[packages/core/src/types.ts:323](https://github.com/ai16z/eliza/blob/7fcf54e7fb2ba027d110afcc319c0b01b3f181dc/packages/core/src/types.ts#L323)
